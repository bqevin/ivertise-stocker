                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                <li class="text-center">
                    <img src="assets/img/find_user.png" class="user-image img-responsive"/>
                    </li>


                    <li>
                        <a class="active-menu"  href="index.php"><i class="fa fa-dashboard fa-3x"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-image fa-3x"></i> Image Contribution</a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a id="contributors" href="#">Contributors</a>
                            </li>
                            <li>
                                <a href="#">View Images</a>
                            </li>
                        </ul>
                      </li>
                     <li>
                        <a  href="ui.php"><i class="fa fa-female fa-3x"></i> Models</a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a id="models" href="#">List Models</a>
                            </li>
                            <li>
                                <a href="#">View Images</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a  href="tab-panel.php"><i class="fa fa-edit fa-3x"></i> MUA</a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a id="mua"  href="#">Artists</a>
                            </li>
                            <li>
                                <a href="#">View Images</a>
                            </li>
                        </ul>
                    </li>
                    <!-- <li>
                        <a href="#"><i class="fa fa-sitemap fa-3x"></i> Multi-Level Dropdown<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="#">Second Level Link</a>
                            </li>
                            <li>
                                <a href="#">Second Level Link</a>
                            </li>
                            <li>
                                <a href="#">Second Level Link<span class="fa arrow"></span></a>
                                <ul class="nav nav-third-level">
                                    <li>
                                        <a href="#">Third Level Link</a>
                                    </li>
                                    <li>
                                        <a href="#">Third Level Link</a>
                                    </li>
                                    <li>
                                        <a href="#">Third Level Link</a>
                                    </li>

                                </ul>

                            </li>
                        </ul>
                      </li> -->
                  <li  >
                        <a  href="blank.php"><i class="fa fa-camera fa-3x"></i> Photographers</a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a id="photographers" href="#">All pro photogrphers</a>
                            </li>
                            <li>
                                <a href="#">View Images</a>
                            </li>
                        </ul>
                    </li>
                    <li  >
                        <a  href="blank.php"><i class="fa fa-file-o fa-3x"></i> Content</a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="#">Landing Page</a>
                            </li>
                            <li>
                                <a href="#">Categories</a>
                            </li>
                        </ul>
                    </li>
                    <li  >
                        <a   href="chart.php"><i class="fa fa-bar-chart-o fa-3x"></i> Statistics</a>
                    </li>
                    <!-- <li  >
                        <a  href="table.php"><i class="fa fa-table fa-3x"></i> Table Examples</a>
                    </li>
                    <li  >
                        <a  href="form.php"><i class="fa fa-edit fa-3x"></i> Forms </a>
                    </li>
                     <li  >
                        <a   href="login.php"><i class="fa fa-bolt fa-3x"></i> Login</a>
                    </li>
                     <li  >
                        <a   href="registeration.php"><i class="fa fa-laptop fa-3x"></i> Registeration</a>
                    </li> -->
                </ul>

            </div>

        </nav>
        <!-- /. NAV SIDE  -->