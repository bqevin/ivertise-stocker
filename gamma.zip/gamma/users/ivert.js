$("img").click(function(){
  // action goes here!!
  alert("Please Log in to dowload this image")
});