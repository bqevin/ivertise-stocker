 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

 <style type="text/css">
 
 li {font-color: #696969!important;}
 li{font-size:20px;
 font-weight:300;}
 .grid_3 > .container i{
      color: #fff;
    font-size: x-large;
    padding-left: 5px;
    padding-bottom: 15px;
 }
 </style>

  <div class="clearfix"> </div>

  <div class="grid_3">
    <div>
    <a target="_blank" href="https://www.facebook.com/Ivertise-Africa-349555375204151"><i class="fa fa-facebook-official"></i></a>
    <a target="_blank" href="http://twitter.com/ivertiseafrica"><i class="fa fa-twitter"></i></a>
    <a target="_blank" href="#"><i class="fa fa-instagram"></i></a>
    <a target="_blank" href="#"><i class="fa fa-google"></i></a>
    <a target="_blank" href="#"><i class="fa fa-google-plus"></i></a>
      <ul id="footer-links">
        <li><a href="terms.php">Terms of Use</a></li>
        <li><a href="license.php">License</a></li>
        <li><a href="privacy.php">Privacy</a></li>
        <li><a href="support.php">Support</a></li>
        <li><a href="about.php">About Us</a></li>
        <li><a href="faq.php">FAQ</a></li>
        <li><a href="#">Categories</a></li>
      </ul>
      <p>Ivertise Africa &copy; 2015. All Rights Reserved &nbsp;&nbsp;&nbsp; | &nbsp;&nbsp;&nbsp;&nbsp;Design by: <a href="#" target="_blank">CloudCore Technologies</a> </p>
    </div>
  </div>