 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

 <style type="text/css">
 
 li {font-color: #696969!important;}
 li{font-size:20px;
 font-weight:300;}
 .grid_3 > .container i{
 	    color: #fff;
    font-size: x-large;
    padding-left: 5px;
    padding-bottom: 15px;
 }
 </style>
  <div class="grid_2">
    <div class="container">
      <div class="col-md-3 col_2">
        <h3>Stock Photo<br>Categories</h3>
      </div>
      <div class="col-md-9 col_5">
        <div class="col_1_of_5 span_1_of_5">
          <ul class="list1">
            <li><a href="">Abstract</a></li>
            <li><a href="#">Animals </a></li>
            <li><a href="#">Buildings/Landmarks</a></li>
            <li><a href="#">Beauty/Fashion</a></li>
             <li><a href="#">Beauty/Fashion</a></li>
              <li><a href="#">Business/Finance</a></li>
          </ul>
        </div>
        <div class="col_1_of_5 span_1_of_5">
          <ul class="list1">
            <li><a href="">Editorials </a></li>
            <li><a href="">Interiors</a></li>
            <li><a href=""></a></li>
            <li><a href="">People</a></li>
             <li><a href="#">Patterns</a></li>
          </ul>
        </div>
        <div class="col_1_of_5 span_1_of_5">
          <ul class="list1">
            <li><a href="">Nature/Parks</a></li>
            <li><a href="">Vintage</a></li>
             <li><a href="#">Icons</a></li>
              <li><a href="#">Food/Drinks</a></li>
   
          </ul>
        </div>
        <div class="col_1_of_5 span_1_of_5">
          <ul class="list1">
            <li><a href="">Wildlife</a></li>
            <li><a href="">Vectors</a></li>
            <li><a href="">Infographics</a></li>
            <li><a href="">Textures</a></li>
          </ul>
        </div>
        <div class="clearfix"></div>
      </div>
      <div class="clearfix"> </div>
    </div>
  </div>  
<!--   <div class="grid_2">
    <div class="container">
      <div class="col-md-3 col_2">
        <h3>Stock Photo<br>Keywords</h3>
      </div>
      <div class="col-md-9 col_5">
        <div class="col_1_of_5 span_1_of_5">
          <ul class="list1">
            <li><a href="">Christmas</a></li>
            <li><a href="#">Christmas Background </a></li>
            <li><a href="#">Christmas Border</a></li>
             <li><a href="#">Family</a></li>
              <li><a href="#">Fireworks</a></li>
          </ul>
        </div>
        <div class="col_1_of_5 span_1_of_5">
          <ul class="list1">
            <li><a href="">Giftbox </a></li>
            <li><a href="">Halloween</a></li>
            <li><a href="">Happy Holidays</a></li>
            <li><a href="">Happy new year 2016</a></li>
             
          </ul>
        </div>
        <div class="col_1_of_5 span_1_of_5">
          <ul class="list1">
            <li><a href="">Merry Christmas</a></li>
            <li><a href="">Reindeer</a></li>
             <li><a href="#">Ribbon</a></li>
              <li><a href="#">Santaclaus</a></li>
   
          </ul>
        </div>
        <div class="col_1_of_5 span_1_of_5">
          <ul class="list1">
            <li><a href="">Shopping</a></li>
            <li><a href="">Snowman</a></li>
            <li><a href="">Thanksgiving</a></li>
            <li><a href="">Winter</a></li>
          </ul>
        </div>
        <div class="clearfix"></div>
      </div>
      <div class="clearfix"> </div>
    </div>
  </div> -->
  <div class="grid_3">
    <div class="container">
    <a target="_blank" href="https://www.facebook.com/Ivertise-Africa-349555375204151"><i class="fa fa-facebook-official"></i></a>
    <a target="_blank" href="http://twitter.com/ivertiseafrica"><i class="fa fa-twitter"></i></a>
    <a target="_blank" href="#"><i class="fa fa-instagram"></i></a>
    <a target="_blank" href="#"><i class="fa fa-google"></i></a>
    <a target="_blank" href="#"><i class="fa fa-google-plus"></i></a>
      <ul id="footer-links">
        <li><a href="terms.php">Terms of Use</a></li>
        <li><a href="license.php">License</a></li>
        <li><a href="privacy.php">Privacy</a></li>
        <li><a href="support.php">Support</a></li>
        <li><a href="about.php">About Us</a></li>
        <li><a href="faq.php">FAQ</a></li>
        <li><a href="#">Categories</a></li>
      </ul>
      <p>Ivertise Africa &copy; 2015. All Rights Reserved &nbsp;&nbsp;&nbsp; | &nbsp;&nbsp;&nbsp;&nbsp;Design by: <a href="#" target="_blank">CloudCore Technologies</a> </p>
    </div>
  </div>