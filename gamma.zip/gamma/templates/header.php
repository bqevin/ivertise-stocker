<!DOCTYPE HTML>
<html>
<head>
  <title>Ivertise Africa | Stock photography and model agency for the African Market</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="keywords" content="" />
  <script type="application/x-javascript">
  addEventListener("load", function() {
    setTimeout(hideURLbar, 0);
  }, false);

  function hideURLbar() {
    window.scrollTo(0, 1);
  }
  </script>
  <link href="ph/css/bootstrap.css" rel='stylesheet' type='text/css' />
  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <!-- Custom Theme files -->
  <link href="ph/css/style.css" rel='stylesheet' type='text/css' />
  

  <!-- Custom Theme files -->
  <!--webfont-->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css"/>
  <link href='https://fonts.googleapis.com/css?family=Quicksand:300,400,700' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800' rel='stylesheet' type='text/css'>
  <script type="text/javascript" src="ph/js/jquery-1.11.1.min.js"></script>
  <script src="ph/js/easyResponsiveTabs.js" type="text/javascript"></script>

  <script src="ph/js/menu_jquery.js"></script>

  <title><?php echo isset($page_title) ? $page_title : "Ivertise Africa"; ?> Ivertise</title>
  <!-- Latest compiled and minified CSS -->
  <link href="ph/css/bootstrap.css" rel='stylesheet' type='text/css' />
  <!-- HTML5 Shiv and Respond.js IE8 support of HTML5 elements and media queries -->
<?php
  include 'db_connect.php';
?>
