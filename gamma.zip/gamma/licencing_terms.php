<?php require_once 'templates/header.php'; ?>
<title>Ivertise | Licencing Terms and Agreements</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style type="text/css">
section.main{height:400px;}
</style>
</head>
<body>
<div class="header">	
      <div class="container"> 
  	     <div class="logo">
			<h1><a href="#"><img src="assets/img/logo.png" alt=""></a></h1>
		 </div>
		 <div class="top_right">
		   <ul>
			<li><a href="register.php">Sign Up</a></li>|
			<li class="login" >
				 <div id="loginContainer"><a href="#" id="loginButton"><span>Log In</span></a>
					  <div id="loginBox">                
						  <form id="loginForm">
			                <fieldset id="body">
			                	<fieldset>
			                          <label for="email">Email Address</label>
			                          <input type="text" name="email" id="email">
			                    </fieldset>
			                    <fieldset>
			                            <label for="password">Password</label>
			                            <input type="password" name="password" id="password">
			                     </fieldset>
			                    <input type="submit" id="login" value="Sign in">
			                	<label for="checkbox"><input type="checkbox" id="checkbox"> <i>Remember me</i></label>
			            	</fieldset>
			                 <span><a href="#">Forgot your password?</a></span>
						   </form>
				        </div>
			      </div>
			  </li>
		   </ul>
	     </div>
	     </div>
		<section class="main">  
		<center>Licencing Terms and Agreements</center>
		</section>
	
<?php require_once 'templates/footer.php'; ?>
</body>
</html>		